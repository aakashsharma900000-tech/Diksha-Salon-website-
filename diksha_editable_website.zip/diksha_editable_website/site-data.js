/*
  DIKSHA MAKEOVERS & SALON — EDIT THIS FILE
  -----------------------------------------
  Change the text between quotes. Keep commas and quote marks in place.
  For your own photos, put image files inside the assets folder and use e.g. "assets/my-bridal-photo.jpg".
*/
const SITE_DATA = {
  businessName: "DIKSHA",
  businessSubtitle: "MAKEOVERS & SALON",
  logo: "assets/diksha-logo.png",
  whatsappNumber: "919929684144", // India country code 91 + your 10 digit number
  phoneDisplay: "9929684144",
  heroEyebrow: "BEAUTY • CARE • SELF LOVE",
  heroScript: "Your beauty, your moment",
  heroTitle: "DIKSHA",
  heroSubTitle: "MAKEOVERS & SALON",
  heroDescription: "Enhance your natural beauty with our professional touch.",
  aboutHeading: "Your beauty.<br><em>Your moment.</em>",
  aboutText: "From timeless bridal looks to everyday self-care, we believe every visit should leave you feeling confident, cared for and beautifully you.",
  offerHeading: "Offers <em>& Specials</em>",
  offerDescription: "Celebrate the season with beauty treats made just for you.",
  offerArtTitle: "Deserves<br><em>a Reward</em>",
  offerArtSubtitle: "SPECIAL FOR YOU",
  offerButtonText: "Ask About Offers ↗",
  services: [
    { name: "Makeup", subtitle: "Bridal • Party • Engagement", image: "https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?auto=format&fit=crop&w=650&q=80" },
    { name: "Hairstyle", subtitle: "Styling • Curls • Hairdos", image: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=650&q=80" },
    { name: "Skin Care", subtitle: "Facial • Clean-up • Glow care", image: "https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?auto=format&fit=crop&w=650&q=80" },
    { name: "Nails & Beauty", subtitle: "Manicure • Waxing • Grooming", image: "https://images.unsplash.com/photo-1604654894610-df63bc536371?auto=format&fit=crop&w=650&q=80" }
  ],
  serviceList: [
    "Bridal & Party Makeup", "Engagement Makeup", "Hairstyling & Hair Setting", "Hair Spa & Hair Care",
    "Facials & Clean-ups", "Skin Care Treatments", "Waxing & Hand Care", "Head Massage & Grooming"
  ],
  gallery: [
    { title: "Bridal Beauty", image: "https://images.unsplash.com/photo-1594465919760-441fe5908ab0?auto=format&fit=crop&w=800&q=85" },
    { title: "Makeup Looks", image: "https://images.unsplash.com/photo-1524250502761-1ac6f2e30d43?auto=format&fit=crop&w=700&q=85" },
    { title: "Hair Styling", image: "https://images.unsplash.com/photo-1560869713-7d0a29430803?auto=format&fit=crop&w=700&q=85" },
    { title: "Beauty Care", image: "https://images.unsplash.com/photo-1512290923902-8a9f81dc236c?auto=format&fit=crop&w=700&q=85" }
  ]
};
