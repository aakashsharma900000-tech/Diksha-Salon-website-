const d = SITE_DATA;
const $ = id => document.getElementById(id);
const waUrl = message => `https://wa.me/${String(d.whatsappNumber).replace(/\D/g, '')}?text=${encodeURIComponent(message)}`;

document.title = `${d.businessName} ${d.businessSubtitle} | Beauty, Care & Self Love`;
$('brandName').textContent = d.businessName;
$('brandSubtitle').textContent = d.businessSubtitle;
$('brandLogo').src = d.logo;
$('brandLogo').alt = `${d.businessName} logo`;
$('brandLogo').onerror = () => { $('brandLogo').style.display = 'none'; };
$('heroEyebrow').textContent = d.heroEyebrow;
$('heroScript').textContent = d.heroScript;
$('heroTitle').textContent = d.heroTitle;
$('heroSubTitle').textContent = d.heroSubTitle;
$('heroDescription').textContent = d.heroDescription;
$('aboutBrandName').textContent = d.businessName;
$('aboutHeading').innerHTML = d.aboutHeading;
$('aboutText').textContent = d.aboutText;
$('offerHeading').innerHTML = d.offerHeading;
$('offerDescription').textContent = d.offerDescription;
$('offerArtTitle').innerHTML = d.offerArtTitle;
$('offerArtSubtitle').textContent = d.offerArtSubtitle;
$('offerButton').textContent = d.offerButtonText;
$('displayPhone').textContent = d.phoneDisplay;
$('footerName').textContent = d.businessName;
$('footerSubtitle').textContent = d.businessSubtitle;
$('copyrightName').textContent = `${d.businessName} ${d.businessSubtitle}`;
$('year').textContent = new Date().getFullYear();

[$('headerBook'), $('heroWhatsApp'), $('offerButton'), $('bookingButton')].forEach((a, i) => {
  const messages = [
    `Hello ${d.businessName} ${d.businessSubtitle}, I want to enquire about your services.`,
    `Hello ${d.businessName} ${d.businessSubtitle}, I would like to book an appointment.`,
    `Hello, please share the current offers at ${d.businessName} ${d.businessSubtitle}.`,
    `Hello ${d.businessName} ${d.businessSubtitle}, I would like to book an appointment.`
  ];
  a.href = waUrl(messages[i]);
});
$('headerBook').textContent = `WhatsApp Booking ↗`;
$('offerButton').textContent = d.offerButtonText;

$('serviceGrid').innerHTML = d.services.map(s => `
  <article class="service-card">
    <img src="${escapeAttr(s.image)}" alt="${escapeAttr(s.name)}" loading="lazy" onerror="this.style.display='none'">
    <h3>${escapeHtml(s.name)}</h3><p>${escapeHtml(s.subtitle)}</p>
    <a href="${waUrl(`Hello, I want to enquire about ${s.name}.`)}" target="_blank" rel="noopener">Enquire now ↗</a>
  </article>`).join('');

$('serviceList').innerHTML = d.serviceList.map(s => `<span>${escapeHtml(s)}</span>`).join('');
$('galleryGrid').innerHTML = d.gallery.map(g => `
  <article class="gallery-item">
    <img src="${escapeAttr(g.image)}" alt="${escapeAttr(g.title)}" loading="lazy" onerror="this.style.display='none'">
    <span>${escapeHtml(g.title)}</span>
  </article>`).join('');

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function escapeAttr(value) { return escapeHtml(value); }

const toggle = $('menuToggle');
const nav = $('nav');
toggle.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  toggle.textContent = open ? '×' : '☰';
  toggle.setAttribute('aria-expanded', String(open));
});
nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
  nav.classList.remove('open'); toggle.textContent = '☰'; toggle.setAttribute('aria-expanded', 'false');
}));
